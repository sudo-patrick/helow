-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 23, 2019 at 03:32 PM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_iot`
--

-- --------------------------------------------------------

--
-- Table structure for table `temps`
--

CREATE TABLE `temps` (
  `id` tinyint(4) NOT NULL,
  `name` varchar(10) DEFAULT NULL,
  `date_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `temps`
--

INSERT INTO `temps` (`id`, `name`, `date_time`) VALUES
(1, 'ON', '2018-07-24 08:28:47'),
(2, 'OFF', '2018-07-24 08:28:57'),
(3, 'ON', '2018-07-24 08:47:24'),
(4, 'OFF', '2018-07-24 08:47:33'),
(5, 'ON', '2018-07-24 09:06:06'),
(6, 'OFF', '2018-07-24 09:06:35'),
(7, 'ON', '2018-07-24 09:08:46'),
(8, 'OFF', '2018-07-24 09:09:05'),
(9, 'ON', '2018-07-24 09:14:16'),
(10, 'OFF', '2018-07-24 09:14:25'),
(11, 'ON', '2018-07-24 09:15:09'),
(12, 'OFF', '2018-07-24 09:15:18'),
(13, 'ON', '2018-07-24 09:15:33'),
(14, 'OFF', '2018-07-24 09:15:36'),
(15, 'ON', '2018-07-24 09:16:17'),
(16, 'OFF', '2018-07-24 09:16:23'),
(17, 'ON', '2018-07-24 09:17:30'),
(18, 'OFF', '2018-07-24 09:17:41'),
(19, 'ON', '2018-07-24 09:17:46'),
(20, 'OFF', '2018-07-24 09:17:49'),
(21, 'ON', '2018-07-24 09:18:03'),
(22, 'OFF', '2018-07-24 09:18:05'),
(23, 'ON', '2018-07-24 09:31:30'),
(24, 'OFF', '2018-07-24 09:31:42'),
(25, 'OFF', '2018-07-25 01:31:26'),
(26, 'ON', '2018-07-25 01:31:31'),
(27, 'OFF', '2018-07-25 01:32:54'),
(28, 'ON', '2018-07-25 01:54:16'),
(29, 'OFF', '2018-07-25 01:57:10');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `temps`
--
ALTER TABLE `temps`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `temps`
--
ALTER TABLE `temps`
  MODIFY `id` tinyint(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
