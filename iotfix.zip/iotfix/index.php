<?php
error_reporting(E_ALL^(E_NOTICE | E_WARNING));
$con=mysqli_connect("localhost","root","","temps");
      // Check connection
if (mysqli_connect_errno())
{
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
} 

  // initialize variables
  $on = "";
  $off = "";
//get the GPIO status
$html = file_get_contents('http://192.168.43.91/status');
if (strpos($html, 'low') !== false) {
    $status = 0;
}
else {
  $status = 1;
}

  if ($_POST["15"] == "1") {
    if ($status == 1) {
      file_get_contents('http://192.168.43.91/gpio/0');
      $status = 0;
      $off ="ON";
      mysqli_query($con,"INSERT INTO db_tes (name) VALUES ('$off')");

      mysqli_close($con);
              
      if (mysqli_errno()){
          echo "<script>alert('Gagal Simpan !!');</script>";
      }else{
          echo "<script> alert('Data berhasil dimasukkan.');window.location = 'index.php'; </script>";
      }  
    }
    elseif ($status == 0) {
      file_get_contents('http://192.168.43.91/gpio/1');
      $status = 1;
      $on ="OFF";
      mysqli_query($con,"INSERT INTO db_tes (name) VALUES ('$on')");

      mysqli_close($con);
              
      if (mysqli_errno()){
          echo "<script>alert('Gagal Simpan !!');</script>";
      }else{
          echo "<script> alert('Data berhasil dimasukkan.');window.location = 'index.php'; </script>";
      }  
    }
  }
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Switch</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
</head>
<style type="text/css">
        body {
            font-size: 19px;
        }
        table{
            width: 50%;
            margin: 30px auto;
            border-collapse: collapse;
            text-align: left;
        }
        tr {
            border-bottom: 1px solid #007bff;
        }
        th, td{
            border: none;
            height: 30px;
            padding: 2px;
        }
        tr:hover {
            background: #F5F5F5;
        }

        form {
            width: 45%;
            margin: 50px auto;
            text-align: left;
            padding: 20px; 
            border: 1px solid #007bff; 
            border-radius: 5px;
        }

        .input-group {
            margin: 10px 0px 10px 0px;
        }
        .input-group label {
            display: block;
            text-align: left;
            margin: 3px;
        }
        .input-group input {
            height: 30px;
            width: 93%;
            padding: 5px 10px;
            font-size: 16px;
            border-radius: 5px;
            border: 1px solid gray;
        }
        .btn {
            padding: 10px;
            font-size: 15px;
            color: white;
            background: #5F9EA0;
            border: none;
            border-radius: 5px;
        }
    </style>
<body>

<div class="container">
  <div class="col-sm-3">
       <h3>Daya Listrik</h3>
        <form  id="form" name="test" action="index.php" method="post">
          <input type="hidden" name="15" value="1"></input>
          <input type="submit" class="<?php if($status == 1) {print("btn btn-primary btn-lg btn-block");} else {print("btn btn-secondary btn-lg btn-block button");} ?>" value="<?php if($status == 1) {print("Turn Off");} else {print("Turn On");} ?>"></input>
        </form>
        <table>
            <tr>
                <td><button onclick="show()">Lihat Record Data</button> </td>
            </tr>
        </table>
    </div>
    </div>
</body>
</html>
<script type="text/javascript">
    function show(){
        window.open('show_table.php');
    }
</script>