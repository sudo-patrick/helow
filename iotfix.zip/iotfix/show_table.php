<html>
    <head>
        <meta name="viewport" content="width=device-width" />
        <title>tampilan database</title>
    </head>
    <style type="text/css">
        body {
            font-size: 19px;
        }
        table{
            width: 50%;
            margin: 30px auto;
            border-collapse: collapse;
            text-align: left;
        }
        tr {
            border-bottom: 1px solid #007bff;
        }
        th, td{
            border: none;
            height: 30px;
            padding: 2px;
        }
        tr:hover {
            background: #007bff;
        }

        form {
            width: 45%;
            margin: 50px auto;
            text-align: left;
            padding: 20px; 
            border: 1px solid #007bff; 
            border-radius: 5px;
        }

        .input-group {
            margin: 10px 0px 10px 0px;
        }
        .input-group label {
            display: block;
            text-align: left;
            margin: 3px;
        }
        .input-group input {
            height: 30px;
            width: 93%;
            padding: 5px 10px;
            font-size: 16px;
            border-radius: 5px;
            border: 1px solid gray;
        }
        .btn {
            padding: 10px;
            font-size: 15px;
            color: white;
            background: #007bff;
            border: none;
            border-radius: 5px;
        }
    </style>
    <body>
        <h2 align="center">Record Data </h2>
		
		
        <?php 
		$con=mysqli_connect("localhost","root","","temps");
			// Check connection
		if (mysqli_connect_errno())
		{
			echo "Failed to connect to MySQL: " . mysqli_connect_error();
		} 
		$results = mysqli_query($con,"SELECT * FROM temps"); 
		?>

        <table width="500" border="15" cellspacing="2" cellpadding="3">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Keadaan</th>
                    <th>Tanggal Dan Waktu</th>
                </tr>
            </thead>
            
            <?php while ($row = mysqli_fetch_array($results)) { ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
					<td><?php echo $row['name']; ?></td>
					<td><?php echo $row['date_time']; ?></td>
                </tr>
            <?php 
			error_reporting(E_ALL^(E_NOTICE | E_WARNING));
			} 
			$url=$_SERVER['REQUEST_URL'];
			header("Refresh: 5; URL=$url");
			?>
        </table>
    </body>
</html>